# Import library for Hybrid Server
import hys
# Check deligate
def hysIsDelegateRequest(server_request, server_key):
    return 1
def hysDelegateRequest(server_request, server_key):
    result = "Testing 123" + "<br>HTPP Method = " + hys.hysGetURLMethod(server_request) + "<br>Session key = " + server_key
    return result
def hysProcessPageRequest(server_request, server_key):
    return ""

# End of file
