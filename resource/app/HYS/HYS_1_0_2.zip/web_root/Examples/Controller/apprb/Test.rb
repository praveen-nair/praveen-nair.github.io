# Check deligate
def hysIsDelegateRequest(server_request, server_key)
    return 1
end
def hysDelegateRequest(server_request, server_key)
    result = "Testing 123" + "<br>HTPP Method = " + HYS.hysGetURLMethod(server_request) + "<br>Session key = " + server_key
    return result
end
def hysProcessPageRequest(server_request, server_key)
    return ""
end


