-- Import library for Hybrid Server

-- Check if the control should be delegated to the controller (Send true for delegating request to controller)
function hysIsDelegateRequest(server_request, server_key)
    return true
end

-- This code is called if the hysIsDelegateRequest returned 1 (TRUE). Send the Body of the response HTML Message.
function hysDelegateRequest(server_request, server_key)
    return "Hello Sample Deletgate.<br>" .. "HTTP Method: " .. hysGetURLMethod(server_request) .. 
    		"<br>URL Query value for 'query1' is " .. hysGetURLParameterValue(server_request, "query1")
end

-- This code is called if the .lua file is places as a file. This is processed when the request is like:
-- http://<host>:<port>/<Filename.lua>
function hysProcessPageRequest(server_request, server_key)
    return "Hello Sample Response."
end
