# require HYS library already included

# This code is called if the .rb file is placed as a file. This is processed when the request is like:
# http://<host>:<port>/<Filename.rb>
def hysProcessPageRequest(server_request, server_key)
	arrUID = ["ID_001", "ID_007"]
	arrPWD = ["001", "JB007"]
	arrNAM = ["Mr 001", "James Bond"]
	index = -1
	foundIndex = 0;
	found = false
	response = $pageContentReject

    userID = HYS.hysGetURLParameterValue(server_request, "userID")
    password = HYS.hysGetURLParameterValue(server_request, "userPWD")
    print userID

    for id in arrUID
    	index = index + 1  
    	if id == userID
    		if arrPWD[index] == password
    			found = true
    			foundIndex = index
    		end
    	end
    end

    if found == true
    	response = $pageContentAllow #{}"Welcome " + arrNAM[index] + "!!"
    end
    return response
end

$pageContentAllow = '<html>'+
'   <head>'+
'       <title>Access Control Example</title>'+
'       <link rel="stylesheet" href="acPage.css">'+
'   </head>'+
'   <body>'+
'       <div class="heading">Access Control Example</div>'+
'       <hr>'+
'       <div class="spacer"></div>'+
'       <div class="loginBox">'+
'           <b>Welcome User!!</b>'
'       </div>'+
'       <div class="spacer"></div>'+
'       <div class="buttonContainer">'+
'           <button class="loginButton">Login</button>'+
'       </div>'+
'   </body>'+
'</html>';

$pageContentReject = '<html>'+
'   <head>'+
'       <title>Access Control Example</title>'+
'       <link rel="stylesheet" href="acPage.css">'+
'   </head>'+
'   <body>'+
'       <div class="heading">Access Control Example</div>'+
'       <hr>'+
'       <div class="spacer"></div>'+
'       <div class="loginBox">'+
'           <b>Sorry! Your access is denied!!</b>'
'       </div>'+
'       <div class="spacer"></div>'+
'       <div class="buttonContainer">'+
'           <button class="loginButton">Login</button>'+
'       </div>'+
'   </body>'+
'</html>';	


#hysProcessPageRequest("", "")