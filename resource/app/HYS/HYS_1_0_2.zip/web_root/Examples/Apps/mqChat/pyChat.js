var selectedChatID = "";
var chatList;
var chatID;
var _ALL = "_ALL"
var POOLING_TIME_FOR_READ = 2000// In millisecond
var POOLING_TIME_FOR_CHATLIST = 5000// In millisecond

$(function() {
	$(".cardChat").addClass("hiddenDiv");
	$(".cardList").addClass("hiddenDiv");
	$(".inputArea").addClass("hiddenDiv");
});

function renderChat(formatedMsg) {
	$("#inlineChat").append(formatedMsg + "<br>");
}

function fireLogin() {
	chatID = $("#chatID").val().trim();
	if( chatID == "" || chatID.search(/ /) != -1 || chatID == "*" || chatID.search(/"/) != -1) {
		alert("Chat ID cannot be blank or cannot have space/\" between chanracters or cannot have be '*'.");
	} else {
		$.ajax({
			type: "GET",
			url: "pyUserCreate.py?" + chatID,
			success: function(data) {
				dataObj = JSON.parse(data);
				if(dataObj.status == "OK") {
					$("#userIdPage").html("").addClass("hiddenDiv").removeClass("userIdPage");
					$(".cardChat").removeClass("hiddenDiv");
					$(".cardList").removeClass("hiddenDiv");
					$(".inputArea").removeClass("hiddenDiv");
					$("#chatIDUser").text(chatID);
					fillChatList();
					createPooledRead();
				} else {
					alert(dataObj.reason);
				}
			},
			error: function() {
				alert("Something went wrong! Terribly wrong!!");
			}
		})
	}
}

function fillChatList() {
	$.ajax({
		type: "GET",
		url: "pyUserList.py",
		success: function(data) {
			chatList = JSON.parse(data);
			jQuery('#inlineChatList').empty()
			$("#inlineChatList").append("<div id='" + _ALL + "' class='chatListID' onclick='selectChatID(this)'>*</div><br>");
			for(i = 0; i < chatList.length; i++) {
				if(chatID !== chatList[i].chatID) {
					$("#inlineChatList").append("<div id='" + chatList[i].chatID + 
													"' class='chatListID'  onclick='selectChatID(this)'>" + 
													chatList[i].chatID + "</div><br>");
				}
			}
			if(selectedChatID === "") {
				$("#" + _ALL).removeClass("chatListID").addClass("chatListIDSel");
				selectedChatID = _ALL;
			} else {
				$("#" + selectedChatID).removeClass("chatListID").addClass("chatListIDSel");
			}
			createPooledList();
		},
		error: function() {
			alert("Something went wrong! Terribly wrong!!");
		}
	})
}

function selectChatID(thisID) {
	newSelection = thisID.getAttribute("id");
	if(selectedChatID !== newSelection) {
		$("#" + newSelection).addClass("chatListIDSel");
		$("#" + selectedChatID).removeClass("chatListIDSel").addClass("chatListID");
		selectedChatID = newSelection;
	}

}

function writeChat(chatMsg) {
	$("#inlineChat").append(chatMsg);
}

function _pushChatToMQ(recipient, payload, isBroadCastMsg) {
	//url: location.origin + "/_system/mq/mq_py/httpMQWriteID.pyc?" + recipient,
	//url: "pySendChat.py?chatID=" + chatID + "&chatTo=" + recipient,
	$.ajax({
		type: "POST",
		url: location.origin + "/_system/mq/mq_py/httpMQWriteID.pyc?" + recipient,
		data: payload,
		success: function(data) {
			$("#inputChatText").val("");
		},
		error: function() {
			alert("Something went wrong! Terribly wrong!!");
		}
	});
}

function submitChat() {
	typedText = $("#inputChatText").val();
	formatedText = "<div class='chat " 
    if (selectedChatID === '_ALL') {
        submitBroadcast()
    }
    else {
        formatedText += "chatID'>" + chatID + " -> " + selectedChatID + "</div><div class='chat chatText'>" + typedText + "</div><br>"
        _pushChatToMQ(selectedChatID, formatedText, false);
        writeChat(formatedText);
    }

}

function submitBroadcast() {
	typedText = $("#inputChatText").val();
	formatedText = "<div class='chat chatBCastID'>" + chatID + " -> *" + "</div><div class='chat chatBCastText'>" + typedText + "</div><br>"
	for(i = 0; i < chatList.length; i++) {
		if(chatID !== chatList[i].chatID) {
			_pushChatToMQ(chatList[i].chatID, formatedText, true);
		}
	}
	writeChat(formatedText);
}

function createPooledRead() {
	setTimeout( function() {
		readUserChatMQ();
	}, POOLING_TIME_FOR_READ)
}

function createPooledList() {
	setTimeout( function() {
		fillChatList();
	}, POOLING_TIME_FOR_CHATLIST)
}

function readUserChatMQ() {
	$.ajax({
		type: "GET",
		url: location.origin + "/_system/mq/mq_py/httpMQReadID.pyc?" + chatID,
		success: function(data) {
			dataObj = JSON.parse(data);
			writeChat(dataObj.payload);
			createPooledRead();
		},
		error: function() {
			alert("Something went wrong! Terribly wrong!! Please refresh the page!");
		}
	});
}

